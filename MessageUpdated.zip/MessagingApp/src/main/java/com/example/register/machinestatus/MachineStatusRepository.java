package com.example.register.machinestatus;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MachineStatusRepository extends JpaRepository<MachineStatus, Integer>{

}
