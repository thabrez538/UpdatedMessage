package com.example.register;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/secure/test/user")
public class UserController {

	    @Autowired
	    private UserService userService;

	    @Autowired
	    private BCryptPasswordEncoder passwordEncoder;

	    @PostMapping("/register")
	    public ResponseEntity<String> registerUser(@RequestBody User user) {
	        String pwd = user.getPassword();
	        String encryptPwd = passwordEncoder.encode(pwd);
	        user.setPassword(encryptPwd);
	        userService.saveUser(user); // Assuming you have a UserService to handle user-related operations
	        return ResponseEntity.ok("User registered Successfully");
	    }

	    @GetMapping("/profile")
	    public ResponseEntity<User> getLoggedInUserProfile() {
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	        String username = authentication.getName();
	        User user = userService.findByUsername(username); // Assuming you have a findByUsername method in UserService
	        return ResponseEntity.ok(user);
	    }

	  

	}



