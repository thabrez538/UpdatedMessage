package com.example.register;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/secure/test/admin")
/* @PreAuthorize("hasRole('ADMIN')") */
public class AdminController {
	@Autowired
	private UserService userService;
	
	 @Autowired
	    private BCryptPasswordEncoder passwordEncoder;

	    @PostMapping("/add")
	    public ResponseEntity<String> addUserByAdmin(@RequestBody User user) {
	        String pwd = user.getPassword();
	        String encryptPwd = passwordEncoder.encode(pwd);
	        user.setPassword(encryptPwd);
	        userService.saveUser(user); 
	        return ResponseEntity.ok("User added Successfully");
	    }
	    
	    @GetMapping("/{userId}")
	    public ResponseEntity<User> getUserDetails(@PathVariable int userId) {
	        // Call a method in your UserService or UserRepository to get the user by ID
	        Optional<User> userOptional = userService.getUserById(userId);

	        if (userOptional.isPresent()) {
	            User user = userOptional.get();
	            return ResponseEntity.ok(user);
	        } else {
	            // Handle the case where the user with the specified ID was not found
	            return ResponseEntity.notFound().build();
	        }
	    }


	    @DeleteMapping("/{userId}")
	    public ResponseEntity<String> deleteUserByAdmin(@PathVariable int userId) {
	        userService.deleteUser(userId);
	        return ResponseEntity.ok("User deleted Successfully");
	    }
	
	
}
