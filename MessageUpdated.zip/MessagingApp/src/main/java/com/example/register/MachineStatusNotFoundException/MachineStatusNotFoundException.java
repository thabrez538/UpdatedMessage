package com.example.register.MachineStatusNotFoundException;

public class MachineStatusNotFoundException extends RuntimeException {
	public MachineStatusNotFoundException(String msg) {
		super(msg);
	}
}
